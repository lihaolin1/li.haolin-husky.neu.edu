Please use:
bash question1.bat
and
bash question2.bat
in your terminal to run my code.

Thank you!