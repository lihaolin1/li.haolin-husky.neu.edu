//package War.xml.assignment;

import javax.xml.transform.*;
import javax.xml.transform.stream.*;

//import org.springframework.boot.SpringApplication;
//import org.springframework.context.ConfigurableApplicationContext;

import java.io.*;

public class transform {
	public static void main(String[] args) {
		try {
			//System.out.println(args[0]);
			String XSL= args[0];//xsl_file;
			
			String INPUT = args[1]; //input_file
			
			String OUTPUT = args[2];//output_file;
			
			StreamSource xslcode =new StreamSource(new File(XSL));
			StreamSource input =new StreamSource(new File(INPUT));
			StreamResult output =new StreamResult(new File(OUTPUT));
			
			TransformerFactory tf =TransformerFactory.newInstance();

			Transformer trans = tf.newTransformer(xslcode);

			trans.transform(input, output);			
		} catch (Exception e) {e.printStackTrace();}
	}
}
